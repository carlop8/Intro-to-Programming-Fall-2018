#CarlIsaac Nicolas
#Intro to Programming
#Cathey Martenseen
#10/30/2018
# This program is a test that counts the amount of correct answers and gives a response based on it.
def main():
    count=0
    q1=input("What color is the bark of a tree?")
    print(q1.lower())
    if q1.lower() == "brown":
        print("Correct")
        count=count+1
    else:
        print("incorrect")
    q2 = input("What color is the leaves of a tree in summer?")
    if q2.lower() == "green":
        print("Correct")
        count = count + 1
    else:
        print("incorrect")
    q3 = input("What color is the sun in most art?")
    if q3.lower() == "yellow":
        print("Correct")
        count = count + 1
    else:
        print("incorrect")
    q4 = input("What is red and blue paint mixed?")
    if q4.lower() == "purple":
        print("Correct")
        count = count + 1
    else:
        print("incorrect")
    q5 = input("What color is the ocean?")
    if q5.lower() == "blue":
        print("Correct")
        count = count + 1
    else:
        print("incorrect")
    if count >= 4:
        print("Amazing!")
    elif count >=2 and count <=5:
        print("Good Job!")
    else:
        print("Better luck next time")
    input("enter to end")

main()

