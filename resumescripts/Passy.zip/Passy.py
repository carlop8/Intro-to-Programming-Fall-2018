#Lab6
#CarlIsaac Nicolas
#9/28/2018
def get_first_and_last():
    # get user first and last name
    global first
    first = input()
    global last
    last = input()


def create_username():
    # create username
    global uname
    uname= first + "." + last
    return uname

def create_password():
    #ask user create password
    passwd = input("Create your password")
    while len(passwd)<8:
        print('Password is too short')
        passwd=input('New password')
    while passwd.lower() == passwd:
        print('password needs capital letter')
        passwd = input('New password')
    for i in passwd
    print('good')
    return passwd

def main():
    first_and_last_name_list=get_first_and_last()
    username=create_username()
    password=create_password()
    print('Your email address is', username + '@marist.edu')
main()